<?php
/**
 * Single Product hooks.
 *
 * @package Ecomus
 */

namespace Ecomus\WooCommerce\Single_Product;

use Ecomus\Helper;
use Ecomus\Icon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class of Single Product
 */
class Ask_Question {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'woocommerce_single_product_summary', array( $this, 'ask_question' ), 34 );
		add_action( 'ecomus_after_close_site_footer', array( $this, 'ask_question_content' ) );
	}

	/**
	 * Product Share
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function ask_question() {
		echo '<a href="#" class="ecomus-extra-link-item ecomus-extra-link-item--ask-question em-font-semibold" data-toggle="modal" data-target="product-ask-question-modal">'. Icon::get_svg( 'question' ) . esc_html__( 'Ask a question', 'ecomus' ) . '</a>';
	}

	/**
	 * Product Share content
	 */
	public function ask_question_content() {
		if( ! apply_filters( 'ecomus_ask_question_content', true ) ) {
			return;
		}

		$output = Helper::get_option( 'product_ask_question_form' );

		get_template_part( 'template-parts/modals/product-ask-question', '', $output );
	}
}
