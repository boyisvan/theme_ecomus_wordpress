<?php

/**
 * Template part for displaying the language
 *
 * @package Ecomus
 */

?>

<div class="header-language ecomus-language ecomus-currency-language em-color-dark">
	<?php echo \Ecomus\WooCommerce\Language::language_switcher(); ?>
</div>